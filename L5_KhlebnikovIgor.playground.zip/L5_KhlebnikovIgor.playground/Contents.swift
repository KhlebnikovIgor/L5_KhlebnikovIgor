import UIKit

enum StateACar{
    enum EngineState:String{
        case on = "Включен"
        case off = "Выключен"
    }
    enum Windows:String{
        case open="Открыты"
        case close="Закрыты"
    }
}

enum Color{
    case red
    case black
    case silver
    case gray
    case white
}

protocol Car{
    var model: String{get set}//Наименование модели
    var yearOfIssue: String{get set}//год выпуска
    var length:Int?{get set}//длина
    var width:Int?{get set}//ширина
    var height:Int?{get set}//высота
    var enginePower:Int?{get set}//мощность двигателя
    var engineCapacity:Double?{get set}//объем двигателя
    
    var engineState : StateACar.EngineState?{get set}//двигатель включен/выключен
    var windowsState : StateACar.Windows?{get set}//окна открыты/закрыты
    func printDescription()
}

extension Car{
    mutating func openWindows(){
        windowsState = .open
    }
    mutating func closeWindows(){
        windowsState = .close
    }
    mutating func startEngine(){
        engineState = .on
    }
    mutating func stopEngine(){
        engineState = .off
    }
    
}

class SportCar: Car, CustomStringConvertible{
    var description: String{return String(describing:"Автомобиль модель: \(model), год выпуска: \(yearOfIssue)г., мощность двигателя: \(enginePower!) л.с., объем двигателя: \(engineCapacity!) литра, максимальная скорость: \(maxSpeed!) км/ч")}
    var model: String
    var yearOfIssue: String
    init(model: String, yearOfIssue: String, enginePower: Int, engineCapacity:Double, maxSpeed : Int) {
        self.model = model
        self.yearOfIssue = yearOfIssue
        self.enginePower = enginePower
        self.engineCapacity = engineCapacity
        self.maxSpeed = maxSpeed
    }

    var length: Int?
    var width: Int?
    var height: Int?
    var enginePower: Int?
    var engineCapacity: Double?
    var engineState: StateACar.EngineState?
    var windowsState: StateACar.Windows?

    enum BodyType{
    case sedan
    case hatchback
    case liftback
    case coupe
    case roadster
    }
    enum Transmission{
        case AKPP//автоматическая коробка передач
        case MKPP//механическая коробка передач
    }

    var bodyType:BodyType?//тип кузова
    var color:Color?//цвет кузова
    var typeTransmission:Transmission?//тип трансмиссии
    var maxSpeed:Int?//максимальная скорость км/ч
    func openWindows() {
        windowsState = .open
    }

    func printDescription() {
        print(description + ", цвет кузова: \(color!), тип кузова: \(bodyType!)")
    }
    
    
}

class TruckCar: Car, CustomStringConvertible{
    var model: String
    var yearOfIssue: String
    var length: Int?
    var width: Int?
    var height: Int?
    var enginePower: Int?
    var engineCapacity: Double?
    var engineState: StateACar.EngineState?
    var windowsState: StateACar.Windows?
    func printDescription() {
        print (description + ", мощность двигателя: \(enginePower!) л.с., объем двигателя: \(engineCapacity!) литра, грузоподъемность: \(loadingCapacity!) тонн")
    }
    
    var description: String{return String(describing: "Автомобиль модель: \(model), год выпуска: \(yearOfIssue)г.")}
    
    var volume:Int?//объем кузова
    var loadingCapacity:Int?//грузоподъемность в тоннах
    init(model: String, yearOfIssue: String) {
        self.model = model
        self.yearOfIssue = yearOfIssue
    }
}

var toyotaSupra = SportCar(model: "TOYOTA Supra", yearOfIssue: "2002",enginePower: 197,engineCapacity: 3.5,maxSpeed: 250)
toyotaSupra.bodyType = .coupe
toyotaSupra.color = .red
toyotaSupra.typeTransmission = .AKPP
toyotaSupra.startEngine()
toyotaSupra.openWindows()
toyotaSupra.printDescription()

var truckMan = TruckCar(model: "MAN TGX", yearOfIssue: "2008")
truckMan.engineCapacity = 4.5
truckMan.enginePower = 480
truckMan.loadingCapacity = 80
truckMan.printDescription()
